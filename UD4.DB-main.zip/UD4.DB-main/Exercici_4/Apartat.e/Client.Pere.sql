Select pòlissa
from polissa, client
where client.Client_DNI = polissa.Client_Client_DNI
and client.nom = “__”;   #Pere