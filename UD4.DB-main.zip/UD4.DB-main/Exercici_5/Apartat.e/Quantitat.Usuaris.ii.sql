select different (vehicle.Client_DNI = client)
from vehicle