select Producte.Codi_Intern, Producte.producte_nom, Producte.IVA, Producte.Codi_Barres

from Producte.Codi_Barres != “”

where producte.iva = “10%”;