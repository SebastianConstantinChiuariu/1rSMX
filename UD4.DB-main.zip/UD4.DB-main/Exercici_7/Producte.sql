SELECT Codi_intern, producte.nom, iva, Codi_barres
from Producte 
Where codi_barres != ''
	and. iva = "10%"Ticket