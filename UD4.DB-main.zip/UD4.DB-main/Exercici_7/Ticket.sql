Select NºFactura, Ticket.data, Hora, Empleat.id,
SUMA ( 